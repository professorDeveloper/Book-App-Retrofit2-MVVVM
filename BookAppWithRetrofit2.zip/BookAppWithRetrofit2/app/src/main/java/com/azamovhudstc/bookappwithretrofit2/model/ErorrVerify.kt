package com.azamovhudstc.bookappwithretrofit2.model


import com.google.gson.annotations.SerializedName

data class ErorrVerify(
    @SerializedName("message")
    val message: String
)