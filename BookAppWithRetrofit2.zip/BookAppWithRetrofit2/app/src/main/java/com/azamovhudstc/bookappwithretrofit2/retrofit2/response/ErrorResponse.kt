package com.azamovhudstc.bookappwithretrofit2.retrofit2.response

import com.google.gson.annotations.SerializedName

data class ErrorResponse(
    val message: String
)