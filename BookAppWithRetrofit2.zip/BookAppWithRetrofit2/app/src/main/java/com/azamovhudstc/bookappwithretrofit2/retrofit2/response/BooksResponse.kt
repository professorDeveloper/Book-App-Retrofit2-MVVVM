package com.azamovhudstc.bookappwithretrofit2.retrofit2.response



class BooksResponse : ArrayList<BooksResponseItem>()